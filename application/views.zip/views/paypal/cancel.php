<div class="col-lg-12">
<h4 class="error">We are sorry! Your transaction was canceled.</h4>
<a href="<?php echo base_url('products'); ?>">Back to Products</a>
</div>