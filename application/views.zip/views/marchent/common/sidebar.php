<div class="sidebar-wrapper">
    <ul class="nav">
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo base_url(); ?>marchent">
                <i class="material-icons">dashboard</i>
                <p>Dashboard</p>
            </a>
        </li>
         
        <li class="nav-item ">
            <a class="nav-link" href="<?php echo base_url();?>marchent/getDeliveryDetails">
                <i class="material-icons">content_paste</i>
                <p>Total Delivery</p>
            </a>
        </li>
        <li class="nav-item ">
            <a class="nav-link" href="<?php echo base_url();?>marchent/getTotalPending">
                <i class="material-icons">library_books</i>
                <p>Total Pending</p>
            </a>
        </li>
        <li class="nav-item ">
            <a class="nav-link" href="<?php echo base_url();?>marchent/paymentHistory">
                <i class="material-icons">bubble_chart</i>
                <p>Payment History</p>
            </a>
        </li>

    </ul>
</div>