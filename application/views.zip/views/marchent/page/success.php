<div class="content">
    <div class="container-fluid">

        <div class="card">

            <div class="row">
                <div class="container">
<a href="<?php echo base_url();?>marchent"><button class="btn btn-primary">Back</button></a>
                <center>
    <h1>Successfully Update Profile.</h1>
</center><br>

                </div>
            </div>
        </div>
    </div>
</div>

