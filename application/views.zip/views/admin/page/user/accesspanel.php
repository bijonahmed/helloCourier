<?php

echo "<h2>Under Construction....</h2>"
 
//$pass = trim($this->session->userdata('uPass'));
//$result = $this->db->query("SELECT * FROM tbl_user WHERE user_name='$userName' AND password='$pass' AND status='1'")->row();
//echo "<pre>";
//print_r($user_id)
?>