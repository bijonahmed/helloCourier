<script src="<?php echo base_url(); ?>resource/assets/libs/jquery/dist/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>resource/admin/assets/js/jquery-ui.js"></script>
<script src="<?php echo base_url(); ?>resource/admin/assets/js/popper.min.js"></script>
<script src="<?php echo base_url(); ?>resource/admin/assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>resource/admin/assets/plugins/simplebar/js/simplebar.js"></script>
<script src="<?php echo base_url(); ?>resource/admin/assets/js/waves.js"></script>
<script src="<?php echo base_url(); ?>resource/admin/assets/js/sidebar-menu.js"></script>
<script src="<?php echo base_url(); ?>resource/admin/assets/js/app-script.js"></script>
<script src="<?php echo base_url(); ?>resource/admin/assets/js/selecdropdownjs.js"></script>
<script src="<?php echo base_url(); ?>resource/admin/assets/plugins/notifications/js/lobibox.min.js"></script>
<script src="<?php echo base_url(); ?>resource/admin/assets/plugins/notifications/js/notifications.min.js"></script>
<script src="<?php echo base_url(); ?>resource/admin/assets/plugins/notifications/js/notification-custom-script.js"></script>
<link rel="stylesheet" href="<?php echo base_url(); ?>resource/admin/assets/plugins/notifications/css/lobibox.min.css"/>